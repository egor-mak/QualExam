﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Exam5.ModelEF;

namespace Exam5
{
    public partial class Form1 : Form
    {
        Model2 db = new Model2();
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            DialogResult dialogresult = form.ShowDialog();
        }
        private void button1_Click1(object sender, EventArgs e)
        {
            string trueLogin, truePassword, Login, Password;
            Login = "Administrator";
            Password = "qaz";
            trueLogin = LoginBox.Text;
            truePassword = PasswordBox.Text;
            if (trueLogin == Login && truePassword == Password)
            {
                Form1 form = new Form1();
                this.Hide();
                form.Show();
            }
            else
            {
                MessageBox.Show("Был введён неверный логин или пароль! Пожалуйста, повторите попытку");
            }
        }
    }
}

