﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Exam5.ModelEF;

namespace Exam5
{
    public partial class Form3 : Form
    {
        public Model1 db { get; set; }
        public Form3()
        {
            InitializeComponent();
        }
        private void Form2Edit_Load(object sender, EventArgs e)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == " " || textBox2.Text == " ")
            {
                MessageBox.Show("Нужно ввести все требуемые данные!");
                return;
            }
            int id;
            bool b = int.TryParse(textBox1.Text, out id);
            if (b == false)
            {
                MessageBox.Show("Неверный формат ID - " + textBox1.Text);
                return;
            }
            Registration reg = new Registration();
            reg.ID = id;
            reg.Name = textBox2.Text;
            reg.Surname = textBox3.Text;
            reg.Post = textBox4.Text;
            reg.Events = textBox5.Text;
            reg.Address = textBox6.Text;
            reg.Country = textBox7.Text;
            reg.City = textBox8.Text;
            reg.Region = textBox9.Text;
            reg.Phone = textBox10.Text;
            reg.Indeks = textBox11.Text;
            reg.Fax = textBox12.Text;
            db.Registration.Add(reg);
            try
            {
                db.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }
    }
}
