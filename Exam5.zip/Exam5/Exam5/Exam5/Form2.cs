﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Exam5.ModelEF;

namespace Exam5
{
    public partial class Form2 : Form
    {
        Model1 db = new Model1();
        private Form1 _form1;
        public Form2(Form1 form1)
        {
            _form1 = form1;
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            _form1.Visible = true;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Visible = false;
            _form1.Visible = true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.db = db;
            DialogResult dr = form.ShowDialog();
            if (dr == DialogResult.OK)
            {
                registrationBindingSource.DataSource = db.Registration.ToList();
            }
        }
    }
}